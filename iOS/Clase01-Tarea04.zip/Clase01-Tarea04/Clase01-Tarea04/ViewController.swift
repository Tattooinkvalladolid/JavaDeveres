//
//  ViewController.swift
//  Clase01-Tarea04
//
//  Created by Apple on 23/5/17.
//  Copyright © 2017 TattooInkValladolid. All rights reserved.
//

import UIKit
class ViewController: UIViewController {
    
    
    let nombre:String = "Boris"
    let edad:Int = 18
    var MoF = ""
    let vip = " Usted tiene el previlegio de entrar en la zona VIP ahi tendra una mesa reservada solo para ti y tus invitados y todo all inclusive incluendo chofer para llevarle donde les plasca."
    let entrar = "Puede uste entrar en la disco"
    let nopuedes = "Usted no puede entrar en la disco porque eres menor de edad para poder entrar deveria ser mayor de edad"
    let Proibido = "Usted tiene la entrada proibida en la disco no puede entrar razones posibles , pelea , problematico , destrozo de imobilario , cuentas no pagadas"
    
    @IBOutlet weak var nombreTF: UITextField!
    @IBOutlet weak var edadTF: UITextField!
  
    @IBOutlet weak var MoFControler: UISegmentedControl!
    @IBAction func elijirMoF(_ sender: Any) {
        if MoFControler.selectedSegmentIndex == 1 {
            MoF = "Señor"
        }else if MoFControler.selectedSegmentIndex == 2{
            MoF = "Señora"
        }else{
            MoF = ""
        }
            }
    @IBOutlet weak var mensajeTF: UITextView!
    @IBAction func butonComprobar(_ sender: Any) {
        
        
        if edadTF.text == "" || nombreTF.text == "" {
            mensajeTF.text =  " Deven rellenar todos los campos obligatorisos"
            
        }else{
            let edadTFINT: Int? = Int(edadTF.text!)
            
            if nombreTF.text == nombre && edadTFINT == 33 {
                mensajeTF.text = "\(MoF) \(vip)"
                
            }else if edadTFINT! >= edad     {
                if nombreTF.text == "jorge"{
                    mensajeTF.text = "\(MoF) \(Proibido)"
                    
                }else{
                    mensajeTF.text = "\(MoF) \(entrar) "
                }
                
            }else if edadTFINT! < 18 {
                mensajeTF.text = "\(MoF) \(nopuedes)"
                
            }else  {
                mensajeTF.text = "Deve de rellenar todos los campos obligatorios no se puede entrar sin rellenar los campos inten"
            }
            
            nombreTF.text = ""
            edadTF.text = ""
        }

        
    }

    
    

}

